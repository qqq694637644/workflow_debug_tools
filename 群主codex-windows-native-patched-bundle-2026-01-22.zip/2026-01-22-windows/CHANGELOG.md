
# Changelog

## windows-native patch (2026-04-11)
- 新增 `install-skill-windows.ps1`，支持用户级/仓库级安装到 `.agents/skills/`
- 顶层 `README.md` 改为 Windows 原生安装说明，不再把 `~/.codex/prompts/` 当主路径
- 新增 `WINDOWS_ONLY_AUDIT.md` 记录 Windows 问题与修复
- 新增 `assets/bin/gxd-subagent-shim.cmd` 与 `assets/bin/gxd-subagent-shim.ps1`
- 修复 `gxd_subagent_shim` 的 Windows 关键问题：
  - Codex `resume` 命令顺序错误
  - Codex JSONL 输出的 `thread_id/session_id` 提取不完整
  - `fcntl` 导致的 Windows 文件锁缺失
  - `run_id/task_id` 含 Windows 非法文件名字符时的落盘失败
  - shim CLI 缺少 `--help`、文件输入、stdin 输入能力
- `SKILL.md`、`agent_v2.2.md`、`master_contract.md`、`references/gxd-subagent-shim.md` 全部切到 Windows / PowerShell 语义

## v2.0.1 (2026-01-22)
- 新增`个人思考/AI使用心得.md`
- 删除`综合/agent_v1.1.md`与`综合/gxd_subagent_shim.zip`（已用skill代替）
- 新增`综合/zhukong-orchestrator_v1.0.1.zip`，我将主控模式封装成了一个skill
- `zhukong-orchestrator_v1.0.1.zip`优化了如下几点：
  - 1，在prompt里增加了超时的说明，防止主控提前终止subagent进程
  - 2，优化了subagent的落盘功能、对backend是codex情况下的输出进行裁剪、减少对主控上下文的污染，具体改动详见`综合/zhukong-orchestrator_v1.0.1/assets/gxd-subagent-shim-0.2.3/CHANGELOG.md`
  - 3、在对话过程中，可以随时切换模式，只要你提到“使用主控模式”或者“主控模式”时，该skill就会触发
  - 新增`往期内容文字版精华总结/V20260117-Metacognition01-AuditYourBlindSpots.md`

## v2.0 (2026-01-10)

- 新增 `综合/`：把“直接可用”的核心文件集中到一个目录（避免用户没看完往期视频一头雾水）
  - `agent.md`（档位二入口）
  - `agent_v2.2.md` + `master_contract.md`（档位三入口与契约模板）
  - `gxd_subagent_shim.zip`（打包为统一文件名，便于分发）
- 新增 `往期视频文字版精华总结/`：基于 ghostlab 内容库生成的文字版总结（含 highlights + insights）
- 顶层 README 重写：加入 P0 唯一入口 + 档位决策规则 + 最小成功路径 + 常见坑

## v1.0

- 原始交付（保留在 `往期内容/` 与旧版 zip 中）
