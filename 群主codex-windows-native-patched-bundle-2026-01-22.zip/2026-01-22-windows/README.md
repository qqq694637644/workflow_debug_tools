# Windows 原生入口（Codex CLI）

这份包已经按 **Windows 原生使用** 重新整理过：

- 只保留真正需要的入口与运行时文件。
- 不再要求 `~/.codex/prompts/`。
- 不再依赖已删除的 `agent.md` 或 `gxd_subagent_shim.zip`。
- 不使用 WSL、Git Bash、兼容层；默认就是 **PowerShell + Windows 原生 Codex CLI**。

## 你真正要用的内容

- `综合\zhukong-orchestrator_v1.0.1\`：**实际可安装的 skill**。
- `综合\agent_v2.2.md`：契约式主控的说明/参考版本。
- `综合\master_contract.md`：主控契约模板。
- `WINDOWS_ONLY_AUDIT.md`：这次 Windows 适配修补的审计说明。

## 不要再按旧说明使用

下面这些在这个整理后的 Windows 版本里都不是正确入口：

- `agent.md`
- `综合\gxd_subagent_shim.zip`
- `~/.codex/prompts/`
- bash / `PYTHONPATH=... python -m ...` 这一套 Linux 写法

## 前置条件

在 Windows 上请先准备：

```powershell
npm install -g @openai/codex
```

以及 Python 3（保证 `py -3` 或 `python` 至少有一个可用）。

## 安装 skill（推荐）

在这个包的根目录执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\install-skill-windows.ps1
```

默认会安装到：

```text
$HOME\.agents\skills\zhukong-orchestrator
```

如果你希望只给当前仓库使用，可以改成仓库级安装：

```powershell
powershell -ExecutionPolicy Bypass -File .\install-skill-windows.ps1 -Scope Repo -RepoRoot <你的仓库根目录>
```

## 手动安装（可选）

把下面整个目录复制到目标 skill 目录：

```text
综合\zhukong-orchestrator_v1.0.1
```

目标目录二选一：

```text
$HOME\.agents\skills\zhukong-orchestrator
<你的仓库>\.agents\skills\zhukong-orchestrator
```

## 安装后验证

```powershell
Test-Path "$HOME\.agents\skills\zhukong-orchestrator\SKILL.md"
& "$HOME\.agents\skills\zhukong-orchestrator\assets\bin\gxd-subagent-shim.cmd" --help
```

如果你装到仓库级，就把上面的 `$HOME\.agents\skills\...` 换成仓库里的 `.agents\skills\...` 路径。

## 在 Codex CLI 里怎么用

1. 进入你的项目仓库。
2. 启动 `codex`。
3. 直接描述任务，并明确说“使用主控模式”或“按主控流程”。
4. skill 会走本地 shim，把审计材料落到：

```text
.artifacts\agent_runs\<RUN_ID>\
```

## 目录说明（这次整理后的真实结构）

```text
README.md
CHANGELOG.md
WINDOWS_ONLY_AUDIT.md
install-skill-windows.ps1
综合\
  agent_v2.2.md
  master_contract.md
  zhukong-orchestrator_v1.0.1\
```

## 这次 Windows 修补做了什么

- 新增 Windows wrapper：`gxd-subagent-shim.cmd`、`gxd-subagent-shim.ps1`
- 修复 Codex `resume` 命令拼装
- 修复 Codex JSONL 事件流里的 `thread_id` 提取
- 增加 Windows 文件锁实现
- 增加 Windows 文件名净化，避免 `run_id/task_id` 含非法字符时落盘失败
- shim CLI 新增 `--help`、`@file`、`-`（stdin）三种提示输入方式
- 全部说明改成 Windows / PowerShell 语义

## 参考顺序

建议按这个顺序看：

1. `README.md`
2. `WINDOWS_ONLY_AUDIT.md`
3. `综合\zhukong-orchestrator_v1.0.1\SKILL.md`
4. `综合\master_contract.md`
