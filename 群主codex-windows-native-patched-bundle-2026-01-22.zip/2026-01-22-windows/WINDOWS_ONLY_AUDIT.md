# Windows Only Audit

这份说明只讨论 **Windows 原生 Codex CLI**，不讨论 Linux/WSL/Git Bash 兼容模式。

## 已确认并已修复的问题

### 1. 入口脚本是 bash-only
原项目只有：

```text
assets/bin/gxd-subagent-shim
```

它是 bash wrapper，Windows 原生环境无法直接运行。

已修复：新增

- `assets/bin/gxd-subagent-shim.cmd`
- `assets/bin/gxd-subagent-shim.ps1`

主入口以 `.cmd` 为准。

### 2. 审计锁使用 `fcntl`
`fcntl` 是 Unix-only；Windows 下并发写 `events.jsonl` / `subagent.log` 时没有锁。

已修复：Windows 下改为 `msvcrt` + sidecar lock file。

### 3. Codex `resume` 调用顺序过时
旧实现把 `resume <thread_id>` 拼在 prompt 后面，和当前 Codex CLI 不一致。

已修复：改为

```text
codex exec resume <SESSION_ID> --json <PROMPT>
```

对应的 shim 已同步更新。

### 4. `thread_id` 提取不适配 Codex JSONL
Codex `--json` 是 JSONL 事件流，不是单一 JSON 对象。旧逻辑只适合单对象，容易拿不到 `thread_id`。

已修复：

- 支持 JSONL 事件列表
- 支持 `thread.started` / `session.started`
- 支持 `thread_id` / `session_id` / 嵌套 `thread.id`

### 5. `run_id/task_id` 可能生成 Windows 非法路径
例如 `:`、`?`、`*`、`|`、尾部空格或点号，在 Windows 文件系统会失败。

已修复：新增文件名净化逻辑。

### 6. shim CLI 在 Windows 下缺少可靠输入方式
旧用法要求把整段 JSON 当成一个 shell 参数，在 Windows shell 里很脆弱。

已修复：CLI 现在支持：

- `create <inline>`
- `create @file`
- `create -`（从 stdin 读取）
- `resume <inline|@file|-> <thread_id>`

推荐永远用 `-` 或 `@file`，不要再依赖一整段内联 JSON 引号。

### 7. 顶层索引文档存在过期路径
旧 `README.md` 指向了这些问题路径：

- `agent.md`（已不存在）
- `综合\gxd_subagent_shim.zip`（已不存在）
- `~/.codex/prompts/`（当前不应作为主入口）

已修复：README 与安装方式全部改为 `.agents/skills/`。

## 已做的自检

### 语法自检
已对 shim Python 包执行 `python -m compileall`，通过。

### 行为自检
做了 1 轮本地 smoke test（伪造 `codex` 可执行文件）：

- `create -` 能从 stdin 读取 prompt
- `resume @file <thread_id>` 能读取文件并正确恢复
- `thread_id` 能从 Codex JSONL 事件流中提取并写入 `events.jsonl`
- `run_id` 里的 `:` / `?` 会被自动净化为 Windows 可用目录名

## 仍然保留但不作为当前入口的内容

- `references/agent_v1.1.md`：历史参考，不作为当前 Windows 主入口
- 顶层 `agent_v2.2.md` / `master_contract.md`：保留为参考与模板，但真正执行入口是 skill

## 推荐的 Windows 使用姿势

1. 只安装 `综合\zhukong-orchestrator_v1.0.1`
2. 用 PowerShell
3. 用 `.cmd` wrapper
4. prompt 通过 stdin 或 `@file` 传入
5. 不使用全局 `gxd-subagent-shim`
6. 不使用 bash / WSL / Git Bash
