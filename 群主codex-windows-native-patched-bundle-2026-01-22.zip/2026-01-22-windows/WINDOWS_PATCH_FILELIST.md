# Windows Patch File List

## 新增文件

- `install-skill-windows.ps1`
- `WINDOWS_ONLY_AUDIT.md`
- `WINDOWS_SMOKETEST_RESULT.md`
- `综合/zhukong-orchestrator_v1.0.1/assets/bin/gxd-subagent-shim.cmd`
- `综合/zhukong-orchestrator_v1.0.1/assets/bin/gxd-subagent-shim.ps1`
- `综合/zhukong-orchestrator_v1.0.1/references/agent_v2.2.md`
- `综合/zhukong-orchestrator_v1.0.1/references/master_contract.md`

## 修改文件

- `README.md`
- `CHANGELOG.md`
- `综合/agent_v2.2.md`
- `综合/master_contract.md`
- `综合/zhukong-orchestrator_v1.0.1/SKILL.md`
- `综合/zhukong-orchestrator_v1.0.1/references/gxd-subagent-shim.md`
- `综合/zhukong-orchestrator_v1.0.1/references/agent_v1.1.md`
- `综合/zhukong-orchestrator_v1.0.1/assets/gxd-subagent-shim-0.2.3/README.md`
- `综合/zhukong-orchestrator_v1.0.1/assets/gxd-subagent-shim-0.2.3/gxd_subagent_shim/backend.py`
- `综合/zhukong-orchestrator_v1.0.1/assets/gxd-subagent-shim-0.2.3/gxd_subagent_shim/cli.py`
- `综合/zhukong-orchestrator_v1.0.1/assets/gxd-subagent-shim-0.2.3/gxd_subagent_shim/io/output_extract.py`
- `综合/zhukong-orchestrator_v1.0.1/assets/gxd-subagent-shim-0.2.3/gxd_subagent_shim/util/locks.py`
- `综合/zhukong-orchestrator_v1.0.1/assets/gxd-subagent-shim-0.2.3/gxd_subagent_shim/artifacts/store.py`
