[CmdletBinding()]
param(
    [ValidateSet('User', 'Repo')]
    [string]$Scope = 'User',

    [string]$RepoRoot = (Get-Location).Path,

    [string]$SkillName = 'zhukong-orchestrator'
)

$ErrorActionPreference = 'Stop'

$bundleRoot = Split-Path -Parent $PSCommandPath
$source = Join-Path $bundleRoot '综合\zhukong-orchestrator_v1.0.1'

if (-not (Test-Path $source)) {
    throw "Skill source folder not found: $source"
}

if ($Scope -eq 'User') {
    $destRoot = Join-Path $HOME '.agents\skills'
}
else {
    $destRoot = Join-Path $RepoRoot '.agents\skills'
}

$dest = Join-Path $destRoot $SkillName
New-Item -ItemType Directory -Path $destRoot -Force | Out-Null

if (Test-Path $dest) {
    Remove-Item -Path $dest -Recurse -Force
}

Copy-Item -Path $source -Destination $dest -Recurse -Force

Write-Host "Installed skill to: $dest"
Write-Host ""
Write-Host "Verify with:"
Write-Host "  Test-Path '$dest\SKILL.md'"
Write-Host "  & '$dest\assets\bin\gxd-subagent-shim.cmd' --help"
