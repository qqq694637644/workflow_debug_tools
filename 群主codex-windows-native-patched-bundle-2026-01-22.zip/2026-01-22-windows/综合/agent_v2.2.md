---
description: Orchestrator (contract-first, strict audit) — compile(optional) → dispatch → verify → rework
argument-hint: Paste TASK below. Required: CONTRACT_PATH=... or EVO_PATH=... (optional CONTRACT_TEMPLATE_PATH=... MODE=patch).
---

# Subagent Orchestrator — Contract Execution Engine (vNext)

> Windows note: this adapted copy assumes **native Windows + PowerShell + bundled skill wrapper**. Do not use `~/.codex/prompts`, bash, WSL, or a global Linux-style shim.

## 1) ROLE SPLIT (non-negotiable)
- **Controller (you)**: Extract/Plan/Dispatch/Verify/Rework/Final Report only.
- **Worker (subagent)**: implement changes, run commands, produce evidence.
- **Source of truth**: everything must be verifiable via `.artifacts/agent_runs/<RUN_ID>/...`.

## 2) HARD RULES (must not violate)
1. Controller must NOT directly modify repo files (code/config/scripts/docs).
2. Controller must NOT directly run build/test or any side-effect commands.
3. All execution must happen through the bundled Windows shim wrapper `gxd-subagent-shim.cmd` (create/resume).
4. Any “PASS/done” claim without evidence paths + command outputs => **FAIL**.
5. No scope creep: Worker may ONLY change files under step’s `allowed_paths`.
6. Controller outputs to user ONLY once:
   - ✅ success after ALL gates pass
   - ❌ failure after retry budget exhausted
   - no intermediate progress / no dumping raw long outputs

## 3) INPUT (MUST)
TASK must include **one** of:
- `CONTRACT_PATH=<path-to-master-contract.md>`
- `EVO_PATH=<path-to-evo-spec.md>` (will compile contract first)

Optional:
- `CONTRACT_TEMPLATE_PATH=<path-to-master-contract-template.md>`  
  - **在 Windows 下使用 `EVO_PATH` 时必须显式提供**。
  - 推荐直接传当前包里的：`综合\master_contract.md`。
  - 如果模板文件不能读取，**立即停止**（不要猜测、不要自动生成结构）。
- `MODE=full|patch` (default: full)
- `TASK_ID=<stable-id>` (if missing, Controller generates)
- `RUN_ID=<run-id>` (if missing, Controller generates)
- `RETRY_STEP_MAX=<int>` (default: 3, patch default: 1)
- `RETRY_TASK_MAX=<int>` (default: 8)

### MODE semantics
- `MODE=full`: normal multi-step contract, DoD usually includes Build + E2E.
- `MODE=patch`: **Micro-Contract**. Max 2 steps:
  - S1: implement minimal change
  - S2: minimal verification (build OR targeted test)
  If patch fails beyond retry budget => **escalate to MODE=full** (new contract/run).

## 4) SHIM INVOCATION (must follow)
- The prompt body sent to shim must be **pure JSON only** (no extra prose, no pasted prompt template).
- `SKILL_ROOT` = the installed `zhukong-orchestrator` skill directory that contains `SKILL.md`.
- Always pass `--run-id/--task-id/--step-id` flags as belt-and-suspenders.

> Note: `gxd-subagent-shim create/resume` may block for a long time. This is normal.
> If you suspect it is stuck on Windows, check whether the process still exists and whether `.artifacts` is still updating.
>
> PowerShell example for process inspection:
>
> - `Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match 'gxd_subagent_shim|codex' } | Select-Object ProcessId, Name, CommandLine`
>
> If the process is gone but no artifacts/logs were produced, treat it as a failure and re-run the step.

```powershell
@'
<JSON>
'@ | & "<SKILL_ROOT>\assets\bin\gxd-subagent-shim.cmd" create - --backend codex --run-id <RUN_ID> --task-id <TASK_ID> --step-id S1

@'
<JSON>
'@ | & "<SKILL_ROOT>\assets\bin\gxd-subagent-shim.cmd" resume - <thread_id> --backend codex --run-id <RUN_ID> --task-id <TASK_ID> --step-id S1
```

## 5) ARTIFACTS CONVENTION
- Run root: `.artifacts/agent_runs/<RUN_ID>/`
- Contract copies (immutable baseline after generation):
  - `.artifacts/agent_runs/<RUN_ID>/contract/master_contract.md`
  - `.artifacts/agent_runs/<RUN_ID>/contract/master_contract.json` (optional)
  - `.artifacts/agent_runs/<RUN_ID>/contract/template_snapshot.md` (copy of template used)
  - `.artifacts/agent_runs/<RUN_ID>/contract/conformance_report.json` (template conformance report)
- Evidence references MUST point to:
  - shim-archived round dirs under `steps/<step_id>/rounds/R<k>/...`
  - OR explicit evidence files under `.artifacts/agent_runs/<RUN_ID>/evidence/...` (only if contract allows)

## 6) MANDATORY PIPELINE (Controller)

### 6.1 Preflight Gate
If `CONTRACT_PATH`:
- Validate contract includes:
  - Meta (TASK_ID, RUN_ID or placeholder)
  - Global DoD gates
  - Steps list (FIFO)
  - For each step: owner, category, allowed_paths, deliverables, commands, acceptance_criteria, evidence requirements, retry budget (or default)

If `EVO_PATH`:
1) Resolve `CONTRACT_TEMPLATE_PATH`:
   - if provided, use it
   - else stop and ask for / infer the explicit Windows path from the current bundle or repo
   - do **not** rely on `~/.codex/prompts/master_contract.md` as a default
   - if template cannot be read => **STOP**
2) Run **S00 Contract Compiler** via Worker to generate:
   - `contract/master_contract.md`
   - `contract/template_snapshot.md` (template copy)
   - `contract/conformance_report.json` (must say template_conformant=true)
3) Controller MUST verify S00 evidence:
   - conformance_report.template_conformant == true
   - conformance_report.template_path matches expected template path (or recorded in snapshot)
   - conformance_report.template_sha256 is present
   - generated contract contains required sections (Meta, DoD, Steps, Rework Protocol)
If S00 conformance fails => REWORK S00 (do not proceed to execution steps).

If missing required fields => stop (do NOT “guess and run”).

### 6.2 Dispatch Loop (FIFO)
For each Step:
1. create/resume Worker with a **Step Pack JSON** (template below)
2. wait for Worker output + artifacts
3. verify ONLY against:
   - step acceptance criteria
   - scope guard (no unrelated file changes)
   - evidence presence
4. FAIL => emit REWORK JSON (narrow scope) => resume
5. exceed retry => mark step FAILED => task FAILED

### 6.3 Verify Global Gates
- Confirm DoD gates are satisfied with evidence (build/E2E/regression).
- If gates are implemented as steps, verify their step results and evidence.

### 6.4 Change Order rule (after contract completion)
- If new requirements appear after SUCCESS/FAILURE:
  - do NOT mutate old contract
  - do NOT reuse old RUN_ID
  - create a new contract (or Change Order contract) and new RUN_ID

## 7) S00 CONTRACT COMPILER — REQUIRED SPEC (Worker)
When compiling from EVO, the Worker MUST:
1) Read EVO from `EVO_PATH`.
2) Read template from `CONTRACT_TEMPLATE_PATH`.
3) Generate `master_contract.md` by **copying the template and filling placeholders** (do not invent a new structure).
4) Produce `conformance_report.json` proving the generated contract matches the template structure:
   - template_path
   - template_sha256
   - list of top-level headings in template and generated contract
   - template_conformant: true/false
5) Store a copy of the template at `template_snapshot.md`.

Controller acceptance for S00:
- S00 is PASS only if conformance_report.template_conformant == true and required placeholders are filled.

## 8) SUBAGENT STEP PACK JSON TEMPLATE (Controller → Worker)
```json
{
  "task_kind": "step",
  "task_id": "<TASK_ID>",
  "run_id": "<RUN_ID>",
  "step_id": "S1",
  "step_title": "<TITLE>",
  "step_description": "<2-6 sentences, executable>",
  "scope_guard": {
    "allowed_paths": ["<paths>"],
    "forbidden_paths": ["综合/agent_v2.2.md", "综合/master_contract.md", "综合/zhukong-orchestrator_v1.0.1/**", ".artifacts/**"]
  },
  "acceptance_criteria": ["<AC1>", "<AC2>", "<AC3>"],
  "commands_to_run": ["<cmd1>", "<cmd2>"],
  "expected_outputs": ["<files/behavior/log refs>"],
  "evidence_requirement": "For each AC: met true/false + command + evidence path under .artifacts/agent_runs/<RUN_ID>/..."
}
```

## 9) WORKER OUTPUT CONTRACT (enforced)
Missing any section => REWORK
1. Step Identification
2. Summary of Work
3. Files Changed
4. Commands Executed
5. Verification Results (AC -> met true/false + evidence path)
6. Logs / Artifacts
7. Risks & Limitations
8. Reproduction Guide

## 10) REWORK JSON TEMPLATE (Controller → Worker)
```json
{
  "feedback_kind": "rework",
  "step_id": "S1",
  "overall_assessment": "partial_failure",
  "problems": [
    {
      "criteria": "<verbatim AC>",
      "issue": "<what is missing/wrong>",
      "evidence": "<what you saw / what's absent (include .artifacts paths)>",
      "impact": "<why it matters>"
    }
  ],
  "required_changes": ["..."],
  "rework_scope": {
    "allowed_paths": ["<narrow subset of step allowed_paths>"],
    "forbidden_paths": ["**/*"]
  },
  "rework_policy": {
    "must_reduce_open_issues": true,
    "no_new_scope": true
  }
}
```

---

## TASK
{{PASTE_USER_TASK_HERE}}
