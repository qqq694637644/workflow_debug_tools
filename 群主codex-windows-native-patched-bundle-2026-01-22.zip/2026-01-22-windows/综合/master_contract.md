---
description: Master Contract Template (Controller-Worker) — scope + gates + steps + evidence
argument-hint: Fill placeholders. Save as a real contract file (immutable once execution begins).
---

# MASTER CONTRACT (Controller-Worker) — <TASK_ID>

> This file is a **contract for execution**. Once execution begins, treat it as immutable.
> Any new scope after completion MUST be a Change Order (new contract + new RUN_ID).

## Meta

* TASK_ID: <TASK_ID>
* SPEC (EVO): <EVO_PATH>
* CONTRACT_VERSION: v1
* MODE: <full|patch|co>
* RUN_ID: <RUN_ID>
* Source of Truth: `.artifacts/agent_runs/<RUN_ID>/`

### Template Binding (required when generated from EVO)
* TEMPLATE_SOURCE: <CONTRACT_TEMPLATE_PATH>
* TEMPLATE_SHA256: <sha256-of-template-file>
* TEMPLATE_SNAPSHOT: `.artifacts/agent_runs/<RUN_ID>/contract/template_snapshot.md`
* TEMPLATE_CONFORMANCE_REPORT: `.artifacts/agent_runs/<RUN_ID>/contract/conformance_report.json`

## Global Non-Negotiables

* Controller: plan/dispatch/verify/rework only. No hands-on.
* Worker: execution only via the bundled Windows shim wrapper (`gxd-subagent-shim.cmd`).
* Evidence required: any PASS must reference artifact paths and command outputs.
* No scope creep: only allowed paths per step. Unrelated changes => REWORK.
* Forbidden paths (global): `综合/agent_v2.2.md`, `综合/master_contract.md`, `综合/zhukong-orchestrator_v1.0.1/**`, `.artifacts/**`（除非某个 step 明确允许产出证据）以及工具元数据。

## Evidence Convention

* Any PASS must include:
  * command(s) executed
  * exit code(s)
  * evidence reference under `.artifacts/agent_runs/<RUN_ID>/...`
* No evidence => FAIL.

## Definition of Done (Global Gates)

G1) Build Gate (required):

* Command: <e.g. npm run build>
* PASS: exit code == 0
* Evidence: <path to build log + exit code>

G2) E2E Gate (required unless MODE=patch):

* Command: <e.g. pwsh -File .\tests\E2E\clipboard_sync_image.ps1>
* PASS: exit code == 0 AND assertion(s) satisfied
* Assertion(s): <exact expected output / Select-String pattern / exit conditions>
* Evidence: <path to e2e log + exit code>

(Optional) G3) Regression Gate:

* Command: <e.g. npm test> or <e.g. py -3 -m pytest>
* PASS: exit code == 0
* Evidence: <log path>

## Execution Budget

* Default per-step retry max: 3 (patch default: 1)
* Default task retry max: 8
* Escalation: MODE=patch fails beyond budget => create new MODE=full contract

## Steps (FIFO, MUST NOT reorder)

### S1 — Implement Feature

Owner: Worker  
Category: code  
Allowed Paths:

* <e.g. ShadowVMCore/...>
* <e.g. ShadowVMAgent/...>

Forbidden Paths:

* (global forbidden list applies)

Deliverables:

* <list expected changed files/modules>

Commands to Run (Worker):

* <local sanity commands>
* <optional build smoke>

Acceptance Criteria (must be verifiable):

* AC1: <behavior requirement in measurable terms>
* AC2: <boundary/edge case>
* AC3: <no regression / compile constraints>

Evidence Map (AC -> evidence):

* AC1 -> `.artifacts/agent_runs/<RUN_ID>/steps/S1/rounds/Rk/<...>`
* AC2 -> ...
* AC3 -> ...

### S2 — Add E2E Script

Owner: Worker  
Category: test  
Allowed Paths:

* tests\E2E\<script_name>.ps1
* (optional) tests\E2E\lib\...

Deliverables:

* tests\E2E\<script_name>.ps1

Commands to Run (Worker):

* pwsh -File .\tests\E2E\<script_name>.ps1

Acceptance Criteria:

* AC1: script exits 0 on success
* AC2: script asserts <exact expected output>
* AC3: script is consistent with existing E2E conventions (naming, helper usage, cleanup)

Evidence Map:

* AC1 -> `.artifacts/agent_runs/<RUN_ID>/steps/S2/rounds/Rk/<...>`
* AC2 -> ...
* AC3 -> ...

### S3 — Final Verification Run

Owner: Worker  
Category: infra  
Allowed Paths:

* None (read-only) OR only artifacts output

Commands:

* npm run build
* pwsh -File .\tests\E2E\<script_name>.ps1

Acceptance Criteria:

* AC1: build pass with evidence
* AC2: e2e pass with evidence

Evidence Map:

* AC1 -> `.artifacts/agent_runs/<RUN_ID>/steps/S3/rounds/Rk/<...>`
* AC2 -> ...

## Patch Mode Micro-Contract (MODE=patch)

> Use this only for truly tiny changes (≤ 3 files, no API/protocol/security boundary).

### S1 — Apply Patch
Owner: Worker  
Category: code  
Allowed Paths:

* <explicit file/dir list>

Acceptance Criteria:

* AC1: patch applied
* AC2: no unrelated changes

### S2 — Minimal Verification
Owner: Worker  
Category: infra  
Commands:

* <npm run build OR targeted test>

Acceptance Criteria:

* AC1: command exits 0 with evidence

## Rework Protocol (Controller → Worker)

* Rework JSON must:
  * quote the failed AC verbatim
  * include evidence of failure (artifact paths)
  * include required changes (narrow scope)
  * include rework_scope.allowed_paths to prevent expansion
* Each rework round must reduce open issues.

## Change Order (MODE=co)

If new scope appears after completion:
- Create a new contract (MODE=co) with a new RUN_ID.
- Reference the baseline TASK_ID/RUN_ID in Meta.
- Re-run relevant gates (at least build + impacted E2E).