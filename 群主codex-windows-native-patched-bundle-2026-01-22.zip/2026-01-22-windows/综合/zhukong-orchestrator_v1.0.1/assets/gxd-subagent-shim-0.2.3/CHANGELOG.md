## 变更日志

- 0.2.2 
  - 增强证据落盘功能，只要有输出就落盘为`shim_stdout.txt`
  - 提前写入`create_request.json`，而不是等阶段执行完后写入

- 0.2.3
  - 新增运行提示功能，防止主控在任务还没完成时就强行中断程序
  - 增强输出，只要codex/claude code有stdout，就立刻输出
  - 对subagent是codex时的输出进行了裁剪，只保留重要信息，避免过度污染主控上下文。