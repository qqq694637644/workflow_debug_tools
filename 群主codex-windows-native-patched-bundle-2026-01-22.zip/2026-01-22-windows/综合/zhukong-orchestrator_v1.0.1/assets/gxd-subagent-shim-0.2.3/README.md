# gxd_subagent_shim（Windows native patch）

这是 skill 内置的 `gxd_subagent_shim` 运行时。当前这份整理版只把它当作 **Windows 原生 Codex CLI** 的本地依赖来使用。

## 目标

- 只依赖 Python 标准库
- 适配 Codex `--json` 的 JSONL 事件流
- 保持审计落盘为 best-effort
- 提供 Windows 可直接调用的 wrapper

## 在这个包里的实际入口

优先使用 skill 自带 wrapper，而不是直接手敲 `python -m ...`：

```text
assets\bin\gxd-subagent-shim.cmd
assets\bin\gxd-subagent-shim.ps1
```

## CLI 用法

```text
gxd_subagent_shim (create|resume) <prompt|@file|-> [thread_id] [--backend=...] [--run-id=...] [--task-id=...] [--step-id=...]
```

`<prompt>` 支持三种形式：

- 直接内联字符串
- `@file`：从 UTF-8 文件读取
- `-`：从 stdin 读取

## 推荐用法（PowerShell）

### create

```powershell
@'
{"task_id":"demo","step_id":"S1"}
'@ | & ".\assets\bin\gxd-subagent-shim.cmd" create - --backend codex --run-id demo_run --task-id demo --step-id S1
```

### resume

```powershell
@'
{"feedback_kind":"rework","step_id":"S1"}
'@ | & ".\assets\bin\gxd-subagent-shim.cmd" resume - <thread_id> --backend codex --run-id demo_run --task-id demo --step-id S1
```

## 审计目录

默认写入：

```text
.artifacts\agent_runs\<RUN_ID>\
```

## 开发者调试（仅当你真的在改 shim）

```powershell
py -3 -m pip install -e .
py -3 -m compileall .
```

## 关键环境变量

- `SUBAGENT_BACKEND`
- `SUBAGENT_ARTIFACTS_ROOT`
- `SUBAGENT_SAVE_RAW_IO`
- `SUBAGENT_LEGACY_LOG`
- `SUBAGENT_VALIDATE_INPUT`
- `SUBAGENT_VALIDATE_OUTPUT`
- `SUBAGENT_STDOUT_MODE`
- `SUBAGENT_COMPACT_PROFILE`
- `CODEX_BIN`

## 本次 Windows patch 包含的关键修复

- 新增 Windows wrapper
- 修复 Codex `resume` 命令顺序
- 修复 Codex JSONL 的 `thread_id` 提取
- 修复 Windows 文件锁
- 修复 Windows 文件名非法字符导致的落盘失败
