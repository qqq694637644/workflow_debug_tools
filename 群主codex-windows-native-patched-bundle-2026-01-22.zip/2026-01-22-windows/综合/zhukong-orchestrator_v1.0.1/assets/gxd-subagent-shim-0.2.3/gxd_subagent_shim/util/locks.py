from __future__ import annotations

from pathlib import Path

_LOCK_HANDLE_ATTR = "_gxd_sidecar_lock_handle"


def lock_file_handle(f) -> None:
    """Best-effort advisory lock for concurrent writes.

    Unix uses fcntl on the target file handle.
    Windows falls back to a sidecar *.lock file guarded with msvcrt.
    """
    try:
        import fcntl  # type: ignore

        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        return
    except Exception:
        pass

    try:
        import msvcrt  # type: ignore

        lock_path = Path(str(getattr(f, "name", "subagent.log")) + ".lock")
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        lock_fh = lock_path.open("a+b")
        lock_fh.seek(0)
        msvcrt.locking(lock_fh.fileno(), msvcrt.LK_LOCK, 1)
        setattr(f, _LOCK_HANDLE_ATTR, lock_fh)
    except Exception:
        return


def unlock_file_handle(f) -> None:
    lock_fh = getattr(f, _LOCK_HANDLE_ATTR, None)
    if lock_fh is not None:
        try:
            import msvcrt  # type: ignore

            lock_fh.seek(0)
            msvcrt.locking(lock_fh.fileno(), msvcrt.LK_UNLCK, 1)
        except Exception:
            pass
        try:
            lock_fh.close()
        except Exception:
            pass
        try:
            delattr(f, _LOCK_HANDLE_ATTR)
        except Exception:
            pass
        return

    try:
        import fcntl  # type: ignore

        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except Exception:
        return
