# gxd-subagent-shim quick reference (Windows native)

这个 skill 自带 shim 实现，必须优先调用 **技能目录内** 的 wrapper，不能调用 PATH 上随机版本的 `gxd-subagent-shim`。

## 唯一推荐入口

```text
<SKILL_ROOT>\assets\bin\gxd-subagent-shim.cmd
```

`SKILL_ROOT` 就是 `SKILL.md` 所在目录。

## 推荐调用方式：PowerShell + stdin

### create

```powershell
@'
<JSON>
'@ | & "<SKILL_ROOT>\assets\bin\gxd-subagent-shim.cmd" create - --backend codex --run-id <RUN_ID> --task-id <TASK_ID> --step-id S1
```

### resume

```powershell
@'
<JSON>
'@ | & "<SKILL_ROOT>\assets\bin\gxd-subagent-shim.cmd" resume - <thread_id> --backend codex --run-id <RUN_ID> --task-id <TASK_ID> --step-id S1
```

## 次优调用方式：`@file`

```powershell
& "<SKILL_ROOT>\assets\bin\gxd-subagent-shim.cmd" create "@C:\path\to\step.json" --backend codex --run-id <RUN_ID> --task-id <TASK_ID> --step-id S1
& "<SKILL_ROOT>\assets\bin\gxd-subagent-shim.cmd" resume "@C:\path\to\rework.json" <thread_id> --backend codex --run-id <RUN_ID> --task-id <TASK_ID> --step-id S1
```

## 禁止项

- 禁止执行 `assets\gxd-subagent-shim-0.2.3`（它只是源码目录）
- 禁止使用全局 `gxd-subagent-shim`
- 禁止使用 bash / `PYTHONPATH=... python -m ...` 作为本 skill 的主路径

## 支持的 prompt 输入方式

- 内联字符串（不推荐，Windows 引号容易出错）
- `@file`
- `-`（从 stdin 读取，推荐）

## 常用环境变量

- `SUBAGENT_BACKEND`
- `SUBAGENT_ARTIFACTS_ROOT`
- `SUBAGENT_SAVE_RAW_IO`
- `SUBAGENT_STDOUT_MODE`
- `CODEX_BIN`
